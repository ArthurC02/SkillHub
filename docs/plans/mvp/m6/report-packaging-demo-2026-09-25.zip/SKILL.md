---
name: portable-demo
description: Return a fixed word to demonstrate portable packaging.
license: MIT
---

# Response

Return exactly BETA. Do not use tools or read files.
